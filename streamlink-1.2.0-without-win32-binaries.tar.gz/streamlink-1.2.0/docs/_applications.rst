.. _applications:

:orphan:


.. raw:: html

    <style>
        .rst-content table.field-list td {
            padding-top: 8px;
        }
    </style>

.. |Windows| raw:: html

    <i class="fa fa-fw fa-windows"></i>

.. |MacOS| raw:: html

    <i class="fa fa-fw fa-apple"></i>

.. |Linux| raw:: html

    <i class="fa fa-fw fa-linux"></i>
